#!/bin/bash

timeout 10 $(dirname "$0")/lora_pkt_fwd
sleep 5
$(dirname "$0")/lora_pkt_fwd